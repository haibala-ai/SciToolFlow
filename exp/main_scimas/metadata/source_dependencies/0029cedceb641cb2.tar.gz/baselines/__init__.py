"""Benchmark baseline implementations."""
